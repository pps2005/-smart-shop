/* SMART SHOP v2 (โหลดเป็นไฟล์สุดท้าย) — ธีมสไตล์ Shopee, กล่องยืนยันในแอป, ตะกร้า, แจ้งเตือน,
   แก้ไขคลังตอนปัดซ้าย, แก้ระยะสัญญา, ค้นหาสินค้าจากรูป. ลบบรรทัด <script src="v2.js"> ใน index.html เพื่อย้อนกลับ */
(function () {
  Object.assign(I, {
    bell: '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
    cartp: '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"/><line x1="14" y1="8" x2="14" y2="12"/><line x1="12" y1="10" x2="16" y2="10"/>'
  });
  var st = document.createElement('style');
  st.textContent = [
    ':root{--bg:#f5f5f5;--card:#fff;--line:#ececec;--text:#222;--mute:#757575;--pri:#ee4d2d;--pri2:#ff7337;--green:#26aa99}',
    '[data-theme=dark]{--bg:#121212;--card:#1e1e1e;--line:#2d2d2d;--text:#f2f2f2;--mute:#9a9a9a;--pri:#ff5b3a;--pri2:#ff7a45}',
    '.logo,.side .logo{color:var(--pri)!important}.top .ic{background:transparent;color:var(--pri);position:relative}',
    '.btn,.fab{background:var(--pri)!important;color:#fff!important;border-radius:8px}.fab{border-radius:50%}',
    '.btn.o{background:transparent!important;color:var(--pri)!important;border:1px solid var(--pri)}',
    '.btn.o.dng{color:var(--red)!important;border:2px solid var(--red)!important}',
    '.chip.on{background:transparent!important;color:var(--pri)!important;border-color:var(--pri)}',
    '.card,.pc,.ans{border-radius:12px;border:0}.pc .pr{color:var(--pri)}',
    '.seg{background:transparent;border:0;border-bottom:1px solid var(--line);border-radius:0;padding:0}.seg button{border-radius:0;padding:12px 4px}',
    '.seg .on{background:transparent!important;color:var(--pri)!important;box-shadow:inset 0 -2px 0 var(--pri)}',
    '.bot .on,.side .on{background:transparent!important;color:var(--pri)}',
    '.bg{position:absolute;top:-2px;right:-2px;min-width:18px;height:18px;border-radius:9px;background:var(--pri);color:#fff;font-size:11px;font-weight:700;display:grid;place-items:center;padding:0 4px;border:2px solid var(--card)}',
    '#sw .sb{color:var(--pri)!important}#sw input{padding-right:96px}#sw .sc{position:absolute;right:46px;top:0;bottom:0;width:46px;display:grid;place-items:center;color:var(--pri)}',
    '.sbar{position:sticky;bottom:-24px;margin:14px -16px -24px;padding:10px 12px calc(10px + env(safe-area-inset-bottom,0px));background:var(--card);border-top:1px solid var(--line);display:flex;gap:8px;z-index:3}',
    '.sbar .ib{flex:0 0 56px;display:grid;place-items:center;color:var(--pri);border-right:1px solid var(--line)}',
    '.sbar .go{flex:1;margin:0!important;background:#d0011b!important;border-radius:6px;line-height:1.25}',
    '.cfm{position:fixed;inset:0;z-index:500;background:rgba(0,0,0,.55);display:grid;place-items:center;padding:20px}',
    '.cfm>div{background:var(--card);border-radius:14px;padding:20px;width:100%;max-width:340px}.cfm p{white-space:pre-line;font-size:1.05rem;margin-bottom:6px}',
    '.ci{display:flex;gap:10px;align-items:center;padding:10px 0;border-top:1px solid var(--line)}.ci .gr{flex:1;font-size:.9rem}',
    '.ck{width:28px;height:28px;border-radius:6px;border:2px solid var(--line);display:grid;place-items:center;color:#fff;flex:0 0 28px}.ck.on{background:var(--pri);border-color:var(--pri)}',
    '.qb{width:34px;height:34px;border-radius:8px;border:1px solid var(--line);font-size:1.2rem}',
    '.ev{display:flex;gap:10px;padding:12px 0;border-top:1px solid var(--line)}.ev .gr{flex:1;font-size:.92rem}.ev .nw{background:rgba(238,77,45,.08)}',
    '.tg{display:inline-block;padding:2px 9px;border-radius:99px;font-size:.78rem;font-weight:700;color:#fff;margin-right:6px}.tg.s{background:var(--green)}.tg.r{background:#d0011b}.tg.v{background:#757575}'
  ].join('');
  document.head.appendChild(st);

  var byC = function (c) { return S.prods.find(function (p) { return p.code === c; }); };
  var rpc = function (f, a) { return S.sb.rpc(f, a); };
  var uid = function () { return crypto.randomUUID ? crypto.randomUUID() : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) { var r = Math.random() * 16 | 0; return (c === 'x' ? r : r & 3 | 8).toString(16); }); };
  var cost = function (p) { return Number(p.current_cost); };

  /* ---- 1) ซ่อนเมนูขายสินค้า (ขายจากหน้าสินค้า/ตะกร้า) ---- */
  var si = M.findIndex(function (m) { return m.id === 'sell'; });
  if (si > -1) M.splice(si, 1);

  /* ---- 2) กล่องยืนยันของแอป แทน confirm() ที่มือถือบางตัวบล็อก ---- */
  function ask(msg, labels) {
    return new Promise(function (res) {
      var d = document.createElement('div'), b = document.createElement('div'), p = document.createElement('p');
      d.className = 'cfm'; p.textContent = msg; b.appendChild(p);
      labels.forEach(function (l, i) {
        var x = document.createElement('button');
        x.className = 'btn' + (i === labels.length - 1 ? '' : ' o'); x.textContent = l;
        x.onclick = function () { d.remove(); res(i); }; b.appendChild(x);
      });
      d.appendChild(b); d.onclick = function (e) { if (e.target === d) { d.remove(); res(-1); } };
      document.body.appendChild(d);
    });
  }
  var ASK = {};
  function wrap(fn) {
    return function () {
      var self = this, args = arguments;
      (function go(done) {
        var asked = null, prev = window.confirm, r;
        window.confirm = function (m) { if (done.indexOf(m) > -1) return true; asked = m; throw ASK; };
        try { r = fn.apply(self, args); } catch (e) { if (e !== ASK) { window.confirm = prev; throw e; } }
        if (r && r.then) r = r.catch(function (e) { if (e !== ASK) throw e; });
        if (!asked) { window.confirm = function () { return true; }; return r; }
        window.confirm = prev;
        ask(asked, ['ยกเลิก', 'ยืนยัน']).then(function (i) { if (i === 1) go(done.concat(asked)); });
      })([]);
    };
  }
  window.addEventListener('unhandledrejection', function (e) { toast('เกิดข้อผิดพลาด: ' + ((e.reason && e.reason.message) || e.reason)); });

  /* ---- 3) หน้าสินค้า: แถบล่างแบบ Shopee (QR / ใส่ตะกร้า / ขาย) ---- */
  var d0 = detail;
  detail = function (code) {
    d0(code);
    var p = byC(code), b = $('sbody');
    if (!p || !b) return;
    var f = b.querySelector('[data-a="sale"]');
    if (f && f.parentNode.classList.contains('btns')) f.parentNode.remove();
    b.insertAdjacentHTML('beforeend', '<div class="sbar"><button class="ib" data-a="qr" data-v="' + esc(code) + '" aria-label="QR">' + ic('qr', 24) +
      '</button><button class="ib" data-a="cadd" data-v="' + esc(code) + '" aria-label="ใส่ตะกร้า">' + ic('cartp', 24) +
      '</button><button class="btn go" data-a="sale" data-v="' + esc(code) + '">ขายสินค้า<br><b>฿' + fmt(p.base_price) + '</b></button></div>');
  };

  /* ---- 4) ตะกร้า: เลือกหลายรายการ คิดรวม แล้วขายพร้อมกัน ---- */
  var C = [], cpay = 'cash', cbusy = false;
  var PAYN = { cash: 'เงินสด', card: 'บัตร', transfer: 'โอนเงิน', other: 'อื่น ๆ' };
  function badge(id, n) {
    var b = $(id); if (!b) return;
    var x = b.querySelector('.bg'); if (x) x.remove();
    if (n > 0) b.insertAdjacentHTML('beforeend', '<span class="bg">' + (n > 99 ? '99+' : n) + '</span>');
  }
  function cbadge() { badge('hcart', C.length); }
  var hb = $('theme').parentNode;
  hb.insertAdjacentHTML('afterbegin', '<button class="ic" id="hbell" data-a="notif" aria-label="แจ้งเตือน">' + ic('bell', 20) + '</button><button class="ic" id="hcart" data-a="cart" aria-label="ตะกร้า">' + ic('cart', 20) + '</button>');

  A.cadd = function (code) {
    var p = byC(code), vs = p && p.variants || [];
    if (!vs.length) return toast('สินค้านี้ไม่มีไซส์/ลาย');
    var v0 = vs.find(function (v) { return vq(v) > 0; }) || vs[0];
    openSheet(head('ใส่ตะกร้า') + '<div class="lb">' + esc(p.code + ' ' + p.name) + '</div>' +
      '<label>ไซส์ / ลาย<select id="cv">' + vs.map(function (v) { return '<option value="' + v.id + '"' + (v === v0 ? ' selected' : '') + '>' + esc(vname(v)) + ' (เหลือ ' + vq(v) + ')</option>'; }).join('') + '</select></label>' +
      '<label>ขายจาก<select id="cl"></select></label>' +
      '<div class="two"><label>จำนวน<input id="cq" type="number" inputmode="numeric" min="1" value="1"></label><label>ราคาขาย (บาท)<input id="cp" type="number" inputmode="decimal" min="0" value="' + p.base_price + '"></label></div>' +
      '<div class="err" id="cer"></div><button class="btn" data-a="cok" data-v="' + esc(code) + '">เพิ่มลงตะกร้า</button>');
    var fl = function () {
      var v = vs.find(function (x) { return x.id === $('cv').value; }), first = S.locs.find(function (l) { return lq(v, l.id) > 0; });
      $('cl').innerHTML = S.locs.map(function (l) { return '<option value="' + l.id + '"' + (first && first.id === l.id ? ' selected' : '') + (lq(v, l.id) < 1 ? ' disabled' : '') + '>' + esc(l.name) + ' (เหลือ ' + lq(v, l.id) + ')</option>'; }).join('');
    };
    $('cv').onchange = fl; fl();
  };
  A.cok = function (code) {
    var p = byC(code), v = (p.variants || []).find(function (x) { return x.id === $('cv').value; });
    var loc = $('cl').value, q = parseInt($('cq').value), px = parseFloat($('cp').value), have = lq(v, loc);
    var er = !(q >= 1) ? 'ใส่จำนวนอย่างน้อย 1' : isNaN(px) || px < 0 ? 'ใส่ราคาขาย' : q > have ? 'มีของแค่ ' + have + ' ชิ้นที่นี่' : '';
    if (er) { $('cer').textContent = er; return; }
    var ex = C.find(function (c) { return c.vid === v.id && c.loc === loc && c.px === px; });
    if (ex) ex.q = Math.min(ex.q + q, have); else C.push({ code: code, vid: v.id, loc: loc, q: q, px: px, on: true, key: uid() });
    closeSheet(); cbadge(); toast('ใส่ตะกร้าแล้ว');
  };
  function cline(c) {
    var p = byC(c.code), v = p && (p.variants || []).find(function (x) { return x.id === c.vid; }), l = S.locs.find(function (x) { return x.id === c.loc; });
    return { p: p, v: v, l: l, have: v ? lq(v, c.loc) : 0 };
  }
  function cartSheet(msg) {
    C = C.filter(function (c) { return cline(c).p; });
    cbadge();
    var on = C.filter(function (c) { return c.on; }), rev = 0, cs = 0;
    on.forEach(function (c) { rev += c.px * c.q; cs += cost(cline(c).p) * c.q; });
    var all = C.length && on.length === C.length;
    openSheet(head('ตะกร้า (' + C.length + ')') + (msg ? '<div class="err">' + esc(msg) + '</div>' : '') + (C.length ? '' : '<div class="empty">ตะกร้าว่าง<br>กดไอคอนตะกร้าในหน้าสินค้าเพื่อเพิ่ม</div>') +
      (C.length ? '<button class="row" data-a="ctogall"><span class="ck ' + (all ? 'on' : '') + '">' + (all ? ic('check', 16) : '') + '</span><span>เลือกทั้งหมด</span></button>' : '') +
      C.map(function (c, i) {
        var x = cline(c);
        return '<div class="ci"><button class="ck ' + (c.on ? 'on' : '') + '" data-a="ctog" data-v="' + i + '">' + (c.on ? ic('check', 16) : '') + '</button><div class="th">' + thumb(x.p) + '</div>' +
          '<div class="gr"><b>' + esc(x.p.code) + '</b> ' + esc(x.p.name) + '<br><small>' + esc(vname(x.v || {})) + ' · ' + esc(x.l ? x.l.name : '') + ' · ฿' + fmt(c.px) + '</small>' +
          (c.q > x.have ? '<br><small style="color:var(--red)">เหลือแค่ ' + x.have + '</small>' : '') + '</div>' +
          '<div style="text-align:center"><button class="qb" data-a="cq" data-v="' + i + '|-1">−</button> <b>' + c.q + '</b> <button class="qb" data-a="cq" data-v="' + i + '|1">+</button><br><button class="vbtn" data-a="cdel" data-v="' + i + '">ลบ</button></div></div>';
      }).join('') +
      (C.length ? '<div class="pay" style="margin-top:10px">' + Object.keys(PAYN).map(function (k) { return '<button type="button" class="chip ' + (k === cpay ? 'on' : '') + '" data-a="cpay" data-v="' + k + '">' + PAYN[k] + '</button>'; }).join('') + '</div>' +
        '<div class="sm"><div class="kv"><span>เลือก ' + on.length + ' รายการ · ' + on.reduce(function (a, c) { return a + c.q; }, 0) + ' ชิ้น</span><b>฿' + fmt(rev) + '</b></div><div class="kv"><span>ต้นทุน</span><span>฿' + fmt(cs) + '</span></div>' +
        '<div class="kv"><span>กำไรขั้นต้น</span><b style="color:var(--' + (rev - cs < 0 ? 'red' : 'green') + ')">฿' + fmt(rev - cs) + '</b></div></div>' +
        '<button class="btn" data-a="cgo"' + (on.length ? '' : ' disabled') + '>ขายที่เลือก ฿' + fmt(rev) + '</button>' : ''));
  }
  A.cart = function () { cartSheet(); };
  A.ctog = function (i) { C[i].on = !C[i].on; cartSheet(); };
  A.ctogall = function () { var all = C.every(function (c) { return c.on; }); C.forEach(function (c) { c.on = !all; }); cartSheet(); };
  A.cq = function (v) { var a = v.split('|'), c = C[a[0]]; c.q = Math.max(1, c.q + parseInt(a[1])); cartSheet(); };
  A.cdel = function (i) { C.splice(i, 1); cartSheet(); };
  A.cpay = function (v) { cpay = v; cartSheet(); };
  A.cgo = async function () {
    if (cbusy) return;
    var on = C.filter(function (c) { return c.on; }), bad = on.find(function (c) { return c.q > cline(c).have; });
    if (bad) return toast('มีรายการที่ของไม่พอ ปรับจำนวนก่อน');
    if (on.some(function (c) { return c.px < cost(cline(c).p); }) && !confirm('มีสินค้าราคาขายต่ำกว่าต้นทุน ยืนยันขายหรือไม่?')) return;
    cbusy = true; var ok = 0, tot = 0, fail = '';
    for (var i = 0; i < on.length; i++) {
      var c = on[i], r = await rpc('record_sale', { p_variant_id: c.vid, p_location_id: c.loc, p_qty: c.q, p_price: c.px, p_method: cpay, p_key: c.key });
      if (r.error) { fail = cline(c).p.code + ': ' + r.error.message; break; }
      ok++; tot += c.px * c.q; C.splice(C.indexOf(c), 1);
    }
    cbusy = false;
    await load(); cbadge();
    if (fail) return cartSheet('ขายสำเร็จ ' + ok + ' รายการ แต่หยุดที่ ' + fail);
    closeSheet(); toast('ขายแล้ว ' + ok + ' รายการ รวม ฿' + fmt(tot)); pollN();
  };

  /* ---- 5) ยกเลิกการขาย: เลือก คืนสินค้า / ลงผิด ---- */
  A.vsale = async function (v) {
    var a = v.split('|'), i = await ask('รับคืนหรือยกเลิกรายการขายนี้?\nสินค้าจะกลับเข้าสต๊อกที่เดิม และไม่นับเป็นยอดขาย (เก็บประวัติไว้)', ['ปิด', 'ยกเลิกการขาย (ลงผิด)', 'คืนสินค้า']);
    if (i < 1) return;
    var r = await rpc('void_sale', { p_sale_id: a[0], p_reason: i === 2 ? 'คืนสินค้า' : 'ยกเลิกการขาย' });
    if (r.error) return toast('ทำรายการไม่สำเร็จ: ' + r.error.message);
    await load(); detail(a[1]); toast(i === 2 ? 'รับคืนสินค้าแล้ว คืนเข้าสต๊อกแล้ว' : 'ยกเลิกการขายแล้ว'); pollN();
  };

  /* ---- 6) แจ้งเตือน: ขาย / คืนสินค้า / ยกเลิกการขาย ---- */
  var EV = [], seen = '';
  try { seen = localStorage.getItem('ss_seen') || ''; } catch (e) {}
  function pollN() {
    if (!S.ready || !S.sb) return;
    var from = new Date(Date.now() - 30 * 864e5).toISOString();
    S.sb.from('sales').select('id,product_id,variant_id,qty,unit_price,created_at,voided_at,void_reason')
      .or('created_at.gte.' + from + ',voided_at.gte.' + from).order('created_at', { ascending: false }).limit(300)
      .then(function (r) {
        if (r.error) return;
        EV = [];
        r.data.forEach(function (s) {
          EV.push({ t: s.created_at, k: 's', s: s });
          if (s.voided_at) EV.push({ t: s.voided_at, k: s.void_reason === 'คืนสินค้า' ? 'r' : 'v', s: s });
        });
        EV.sort(function (a, b) { return a.t < b.t ? 1 : -1; });
        if (!seen) { seen = new Date().toISOString(); try { localStorage.setItem('ss_seen', seen); } catch (e) {} }
        badge('hbell', EV.filter(function (e) { return e.t > seen; }).length);
      });
  }
  A.notif = function () {
    var TG = { s: ['ขาย', 's'], r: ['คืนสินค้า', 'r'], v: ['ยกเลิกการขาย', 'v'] }, old = seen;
    openSheet(head('แจ้งเตือน') + (EV.length ? EV.slice(0, 80).map(function (e) {
      var p = S.prods.find(function (x) { return x.id === e.s.product_id; }), amt = e.s.unit_price * e.s.qty;
      return '<button class="ev ' + (e.t > old ? 'nw' : '') + '" style="width:100%;text-align:left" ' + (p ? 'data-a="open" data-v="' + esc(p.code) + '"' : '') + '><div class="gr"><span class="tg ' + TG[e.k][1] + '">' + TG[e.k][0] + '</span>' +
        (p ? esc(p.code + ' ' + p.name) : 'สินค้า') + ' ×' + e.s.qty + '<br><small>' + new Date(e.t).toLocaleString('th-TH', { dateStyle: 'short', timeStyle: 'short' }) + '</small></div>' +
        '<b style="color:var(--' + (e.k === 's' ? 'green' : 'red') + ')">' + (e.k === 's' ? '+' : '−') + '฿' + fmt(amt) + '</b></button>';
    }).join('') : '<div class="empty">ยังไม่มีรายการใน 30 วันนี้</div>'));
    seen = new Date().toISOString(); try { localStorage.setItem('ss_seen', seen); } catch (e) {}
    badge('hbell', 0);
  };
  setInterval(pollN, 60000);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) pollN(); });

  /* ---- 7) หน้าคลัง ปัดซ้าย > แก้ไข: ระบุสถานะ + จำนวนแต่ละที่เอง ---- */
  var SO = [['green', 'พร้อมขาย (หน้าร้าน)'], ['blue', 'สำรอง (อยู่บ้าน)'], ['red', 'เสีย (ระบุเอง)'], ['black', 'หมด (ขายจนหมด)']], sst = '', sbusy = false;
  A.swe = function (code) {
    var p = byC(code); if (!p) return;
    sst = p.status;
    openSheet(head('แก้ไขคลัง') + '<div class="lb">' + esc(p.code + ' ' + p.name) + '</div><div class="lb">สถานะสินค้า (เลือกเอง)</div>' +
      '<div class="rch" id="sst">' + SO.map(function (o) { return '<button type="button" class="chip ' + (o[0] === sst ? 'on' : '') + '" data-a="sstp" data-v="' + o[0] + '"><i class="dt" style="background:var(--' + o[0] + ')"></i>' + o[1] + '</button>'; }).join('') + '</div>' +
      '<div class="lb">จำนวนในแต่ละที่ (แก้เป็นตัวเลขจริงได้เลย)</div>' +
      (p.variants || []).map(function (v) {
        return '<div class="lb" style="margin-top:8px"><small>' + esc(vname(v)) + '</small></div><div class="lq">' + S.locs.map(function (l) {
          return '<label>' + esc(l.name) + (/บ้าน/.test(l.name) ? ' (สำรอง)' : /ร้าน/.test(l.name) ? ' (พร้อมขาย)' : '') + '<input class="sq" type="number" inputmode="numeric" min="0" data-v="' + v.id + '" data-l="' + l.id + '" data-o="' + lq(v, l.id) + '" value="' + lq(v, l.id) + '"></label>';
        }).join('') + '</div>';
      }).join('') + '<div class="err" id="ser2"></div><button class="btn" id="sgo2" data-a="ssave" data-v="' + esc(code) + '">บันทึกคลัง</button>' +
      '<div class="btns"><button class="btn o" data-a="eopen" data-v="' + esc(code) + '">ชื่อ/ราคา/ไซส์</button><button class="btn o" data-a="tfopen" data-v="' + esc(code) + '">ย้ายสินค้า</button></div>');
  };
  A.sstp = function (v) { sst = v; document.querySelectorAll('#sst .chip').forEach(function (c) { c.classList.toggle('on', c.dataset.v === v); }); };
  A.ssave = async function (code) {
    if (sbusy) return;
    var p = byC(code), ch = [], bad = false, er = $('ser2'), btn = $('sgo2');
    document.querySelectorAll('.sq').forEach(function (i) {
      var n = parseInt(i.value);
      if (isNaN(n) || n < 0) bad = true; else if (n !== +i.dataset.o) ch.push([i.dataset.v, i.dataset.l, n]);
    });
    if (bad) { er.textContent = 'ใส่จำนวนตั้งแต่ 0 ขึ้นไปให้ครบทุกช่อง'; return; }
    if (!ch.length && sst === p.status) { closeSheet(); return toast('ไม่มีการเปลี่ยนแปลง'); }
    sbusy = true; btn.disabled = true; btn.textContent = 'กำลังบันทึก...'; er.textContent = '';
    try {
      for (var i = 0; i < ch.length; i++) {
        var r = await rpc('adjust_stock', { p_variant_id: ch[i][0], p_location_id: ch[i][1], p_new_qty: ch[i][2], p_reason: 'ปรับจากหน้าคลัง' });
        if (r.error) throw r.error;
      }
      if (sst !== p.status) {
        var r2 = await rpc('set_product_status', { p_product_id: p.id, p_status: sst, p_note: 'แก้ไขจากหน้าคลัง' });
        if (r2.error) throw r2.error;
      }
      await load(); closeSheet(); toast('บันทึกคลังแล้ว');
    } catch (e) { er.textContent = 'บันทึกไม่สำเร็จ: ' + (e.message || e); btn.disabled = false; btn.textContent = 'บันทึกคลัง'; }
    sbusy = false;
  };

  /* ---- 8) อสังหา: แก้ระยะสัญญา (ย่อ/ขยาย) ---- */
  var os = openSheet;
  openSheet = function (h) {
    os(h);
    var b = $('sbody'), e = b && b.querySelector('button[data-a="rend"]');
    if (e && !b.querySelector('[data-a="rterm"]')) e.insertAdjacentHTML('beforebegin', '<button class="btn o" data-a="rterm" data-v="' + e.dataset.v + '">แก้ไขระยะสัญญา</button>');
  };
  function lastPeriod(first, n) {
    var a = first.split('-').map(Number), t = a[1] - 1 + (n - 1);
    return (a[0] + Math.floor(t / 12)) + '-' + ('0' + (t % 12 + 1)).slice(-2) + '-01';
  }
  A.rterm = function (lid) {
    var l = SSRent.R.leases.find(function (x) { return x.id === lid; }); if (!l) return;
    var o = '';
    for (var m = 1; m <= 36; m++) o += '<option value="' + m + '"' + (m === (l.term_months || 12) ? ' selected' : '') + '>' + (m % 12 === 0 ? (m / 12) + ' ปี (' + m + ' เดือน)' : m + ' เดือน') + '</option>';
    openSheet(head('แก้ไขระยะสัญญา') + '<div class="note" style="margin-bottom:10px">' + esc(SSRent.uname(SSRent.unit(l.unit_id))) + ' · ' + esc((l.tenants || {}).name || '') + '<br>ขยายแล้วระบบเพิ่มงวดให้ ย่อได้เฉพาะงวดท้ายที่ยังไม่ได้รับเงิน</div>' +
      '<label>ระยะสัญญาใหม่ (ไม่เกิน 3 ปี)<select id="ztm">' + o + '</select></label><div class="err" id="zer"></div><button class="btn" id="zgo" data-a="rtermsave" data-v="' + lid + '">บันทึกระยะสัญญา</button>');
  };
  A.rtermsave = async function (lid) {
    var R = SSRent.R, l = R.leases.find(function (x) { return x.id === lid; }), n = parseInt($('ztm').value), last = lastPeriod(l.first_rent_month, n), er = $('zer');
    var paid = SSRent.rowsOf(lid).filter(function (r) { return r.period > last && r._paid > 0; });
    if (paid.length) { er.textContent = 'ย่อไม่ได้ มีงวดที่รับเงินแล้วเลยกำหนดใหม่ (' + paid.length + ' งวด) ลบรายการรับเงินก่อน'; return; }
    $('zgo').disabled = true;
    try {
      var cut = await S.sb.from('rent_payments').update({ cancelled: true }).eq('lease_id', lid).gt('period', last); if (cut.error) throw cut.error;
      var back = await S.sb.from('rent_payments').update({ cancelled: false }).eq('lease_id', lid).lte('period', last); if (back.error) throw back.error;
      var u = await S.sb.from('leases').update({ term_months: n }).eq('id', lid).select('id'); if (u.error) throw u.error;
      if (!u.data || !u.data.length) throw new Error('ไม่มีสิทธิ์แก้ไขสัญญา');
      var e2 = await rpc('ensure_rent_rows'); if (e2.error) throw e2.error;
      await SSRent.reload(); A.runit(l.unit_id); toast('แก้ระยะสัญญาเป็น ' + n + ' เดือนแล้ว');
    } catch (x) { $('zgo').disabled = false; er.textContent = 'บันทึกไม่สำเร็จ: ' + (x.message || x); }
  };

  /* ---- 9) ค้นหาสินค้าจากรูป (โมเดล MobileNet ในเบราว์เซอร์ ไม่มีค่า API; ถ้าโหลดไม่ได้ใช้เทียบสี) ---- */
  var MN = null, FC = {};
  function lj(src) { return new Promise(function (ok, no) { var s = document.createElement('script'); s.src = src; s.onload = ok; s.onerror = no; document.head.appendChild(s); }); }
  async function model() {
    if (MN !== null) return MN;
    try {
      await lj('https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.22.0/dist/tf.min.js');
      await lj('https://cdn.jsdelivr.net/npm/@tensorflow-models/mobilenet@2.1.1/dist/mobilenet.min.js');
      MN = await mobilenet.load({ version: 2, alpha: 1.0 });
    } catch (e) { MN = false; }
    return MN;
  }
  function imEl(src) { return new Promise(function (ok, no) { var i = new Image(); i.crossOrigin = 'anonymous'; i.onload = function () { ok(i); }; i.onerror = no; i.src = src; }); }
  async function feat(img) {
    var m = await model();
    if (m) { var t = m.infer(img, true), a = Array.from(await t.data()); t.dispose(); return a; }
    var c = document.createElement('canvas'); c.width = c.height = 32;
    var x = c.getContext('2d'); x.drawImage(img, 0, 0, 32, 32);
    var d = x.getImageData(0, 0, 32, 32).data, h = new Array(64).fill(0);
    for (var i = 0; i < d.length; i += 4) h[(d[i] >> 6) * 16 + (d[i + 1] >> 6) * 4 + (d[i + 2] >> 6)]++;
    return h;
  }
  function cos(a, b) { var s = 0, x = 0, y = 0; for (var i = 0; i < a.length; i++) { s += a[i] * b[i]; x += a[i] * a[i]; y += b[i] * b[i]; } return s / Math.sqrt(x * y || 1); }
  var sw = $('sw');
  sw.insertAdjacentHTML('beforeend', '<button type="button" class="sc" data-a="isearch" aria-label="ค้นหาด้วยรูป">' + ic('cam', 20) + '</button>');
  A.isearch = function () {
    if (!S.ready) return toast('กำลังโหลดข้อมูล รอสักครู่');
    openSheet(head('ค้นหาสินค้าจากรูป') + '<label class="ph" id="isp" for="isf">' + ic('cam', 34) + '<span>ถ่ายรูป / เลือกรูปสินค้า</span></label><input type="file" id="isf" accept="image/*" style="display:none"><div id="isr"><small>เทียบกับรูปของสินค้าที่ถ่ายเก็บไว้ในระบบ</small></div>');
    $('isf').onchange = function (e) { var f = e.target.files[0]; if (f) isrun(f); };
  };
  async function isrun(f) {
    var url = URL.createObjectURL(f), out = $('isr'), ps = S.prods.filter(function (p) { return S.imgs[p.image_path]; });
    $('isp').innerHTML = '<img src="' + url + '" alt="">';
    if (!ps.length) { out.innerHTML = '<div class="empty">ยังไม่มีสินค้าที่มีรูปในระบบ</div>'; return; }
    out.innerHTML = '<small>กำลังโหลดโมเดลและเปรียบเทียบ...</small>';
    try {
      var q = await feat(await imEl(url)), res = [], mode = MN ? 'n' : 'h';
      for (var i = 0; i < ps.length; i++) {
        var p = ps[i], k = mode + p.image_path;
        try { if (!FC[k]) FC[k] = await feat(await imEl(S.imgs[p.image_path])); res.push([cos(q, FC[k]), p]); } catch (e) {}
        if ($('isr')) $('isr').innerHTML = '<small>เปรียบเทียบ ' + (i + 1) + '/' + ps.length + '</small>';
      }
      if (!$('isr')) return;
      res.sort(function (a, b) { return b[0] - a[0]; });
      out.innerHTML = (res.length ? '<small>' + (MN ? 'ผลจากโมเดลจดจำภาพ' : 'โหลดโมเดลไม่ได้ ใช้เทียบสีแทน (แม่นยำน้อยกว่า)') + ' · เรียงจากคล้ายที่สุด</small>' + res.slice(0, 5).map(function (x) {
        var p = x[1];
        return '<button class="row" style="width:100%;text-align:left" data-a="open" data-v="' + esc(p.code) + '"><div class="th">' + thumb(p) + '</div><div class="gr"><b>' + esc(p.code) + '</b> ' + esc(p.name) + '<br><small>฿' + fmt(p.base_price) + ' · เหลือ ' + pq(p) + '</small></div><b style="color:var(--pri)">' + Math.round(Math.max(0, x[0]) * 100) + '%</b></button>';
      }).join('') : '<div class="empty">เปรียบเทียบรูปไม่สำเร็จ</div>');
    } catch (e) { if ($('isr')) $('isr').innerHTML = '<div class="err">ค้นหาด้วยรูปไม่สำเร็จ: ' + esc(e.message || e) + '</div>'; }
  }

  /* ---- ผูกเข้ากับระบบ ---- */
  Object.keys(A).forEach(function (k) { if (typeof A[k] === 'function') A[k] = wrap(A[k]); });
  var r0 = render;
  render = function () { r0.apply(this, arguments); cbadge(); if (S.ready && !render._p) { render._p = 1; pollN(); } };
  if (window.App && App.stop) { var s0 = App.stop; App.stop = function () { C = []; EV = []; render._p = 0; s0(); }; }
  render();
})();
